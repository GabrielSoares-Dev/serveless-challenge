import { Test, TestingModule } from '@nestjs/testing';
import { HttpStatus, INestApplication } from '@nestjs/common';
import { EmployeesModule } from '../src/employees/employees.module';
import * as request from 'supertest';

describe('EmployeesController (e2e)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [EmployeesModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('/v1/employees (POST)', async () => {
    const response = await request(app.getHttpServer())
      .post('/v1/employees')
      .send({
        name: 'John Doe',
        age: 30,
        role: 'Developer',
      })
      .expect(HttpStatus.CREATED);

    expect(response.body).toEqual({
      statusCode: 201,
      message: 'Employee created',
    });
  });

  it('/v1/employees (GET)', async () => {
    const response = await request(app.getHttpServer())
      .get('/v1/employees')
      .expect(HttpStatus.OK);

    expect(response.body.statusCode).toBe(200);
    expect(response.body.content).toHaveLength(1);
  });
});
