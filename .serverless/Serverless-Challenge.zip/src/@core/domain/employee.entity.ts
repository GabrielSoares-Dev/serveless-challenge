export class Employee {
  id: string;
  name: string;
  age: number;
  role: string;
}
