export interface CreateEmployeeDto {
  name: string;
  age: number;
  role: string;
}
export interface UpdateEmployeeDto {
  name: string;
  age: number;
  role: string;
}
